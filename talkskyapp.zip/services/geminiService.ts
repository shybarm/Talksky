
import { GoogleGenAI, Type } from "@google/genai";
import { WORD_COUNT_TO_FETCH } from '../constants';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateWords = async (category: string, language: string): Promise<string[]> => {
    try {
        const prompt = category === "Random Words" || category === "Palabras aleatorias" || category === "מילים אקראיות" || category === "Случайные слова"
            ? `Generate a list of ${WORD_COUNT_TO_FETCH} unique and fun words or short phrases for a word-guessing party game like 'Taboo' or 'Alias'. The words should be general knowledge and varied in topic. The language for the words should be ${language}.`
            : `Generate a list of ${WORD_COUNT_TO_FETCH} unique words or short phrases for a word-guessing party game like 'Taboo' or 'Alias'. The category is "${category}". The language for the words should be ${language}.`;
        
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.STRING,
                        description: 'A single word or short phrase related to the category.'
                    },
                    description: `A list of ${WORD_COUNT_TO_FETCH} words or phrases.`
                }
            }
        });

        const jsonString = response.text.trim();
        const words = JSON.parse(jsonString);
        return words as string[];
    } catch (error) {
        console.error("Error generating words:", error);
        throw new Error("Failed to generate words from Gemini API.");
    }
};
