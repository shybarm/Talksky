let audioContext: AudioContext | null = null;

const getAudioContext = (): AudioContext | null => {
    if (audioContext) {
        if (audioContext.state === 'suspended') {
            audioContext.resume();
        }
        return audioContext;
    }
    try {
        audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        return audioContext;
    } catch (e) {
        console.error("Web Audio API is not supported in this browser");
        return null;
    }
};

type Sound = 'correct' | 'skip' | 'turnStart' | 'turnEnd' | 'gameOver' | 'click' | 'intro' | 'crowdCheer';

export const playSound = (sound: Sound) => {
    const context = getAudioContext();
    if (!context) return;

    if (context.state === 'suspended') {
        context.resume();
    }

    const now = context.currentTime;
    const oscillator = context.createOscillator();
    const gainNode = context.createGain();
    gainNode.connect(context.destination);
    

    switch (sound) {
        case 'crowdCheer': {
            const bufferSize = context.sampleRate * 1; // 1 second
            const buffer = context.createBuffer(1, bufferSize, context.sampleRate);
            const output = buffer.getChannelData(0);

            for (let i = 0; i < bufferSize; i++) {
                output[i] = Math.random() * 2 - 1;
            }

            const whiteNoise = context.createBufferSource();
            whiteNoise.buffer = buffer;

            const bandpass = context.createBiquadFilter();
            bandpass.type = 'bandpass';
            bandpass.frequency.value = 1000;
            bandpass.Q.value = 0.5;

            const cheerGain = context.createGain();
            whiteNoise.connect(bandpass);
            bandpass.connect(cheerGain);
            cheerGain.connect(context.destination);
            
            cheerGain.gain.setValueAtTime(0, now);
            cheerGain.gain.linearRampToValueAtTime(0.3, now + 0.1);
            cheerGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);

            whiteNoise.start(now);
            whiteNoise.stop(now + 0.5);
            break;
        }
        case 'intro': {
            const fundamental = 130.81; // C3
            oscillator.type = 'sine';
            oscillator.connect(gainNode);
            oscillator.frequency.setValueAtTime(fundamental, now);
            oscillator.frequency.exponentialRampToValueAtTime(fundamental * 4, now + 1.5);
            gainNode.gain.setValueAtTime(0, now);
            gainNode.gain.linearRampToValueAtTime(0.4, now + 0.5);
            gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 2.0);
            oscillator.start(now);
            oscillator.stop(now + 2.0);
            break;
        }
        case 'correct':
            oscillator.connect(gainNode);
            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(600, now);
            oscillator.frequency.linearRampToValueAtTime(800, now + 0.1);
            gainNode.gain.setValueAtTime(0.3, now);
            gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);
            oscillator.start(now);
            oscillator.stop(now + 0.2);
            break;

        case 'skip':
            oscillator.connect(gainNode);
            oscillator.type = 'triangle';
            oscillator.frequency.setValueAtTime(440, now);
            oscillator.frequency.linearRampToValueAtTime(220, now + 0.1);
            gainNode.gain.setValueAtTime(0.2, now);
            gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);
            oscillator.start(now);
            oscillator.stop(now + 0.15);
            break;

        case 'turnStart':
            oscillator.connect(gainNode);
            oscillator.type = 'square';
            oscillator.frequency.setValueAtTime(523.25, now); // C5
            gainNode.gain.setValueAtTime(0.2, now);
            gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);
            oscillator.start(now);
            oscillator.stop(now + 0.2);
            break;

        case 'turnEnd':
            oscillator.connect(gainNode);
            oscillator.type = 'sawtooth';
            oscillator.frequency.setValueAtTime(200, now);
            oscillator.frequency.exponentialRampToValueAtTime(100, now + 0.5);
            gainNode.gain.setValueAtTime(0.4, now);
            gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);
            oscillator.start(now);
            oscillator.stop(now + 0.5);
            break;
            
        case 'gameOver': {
            const playNote = (freq: number, startTime: number, duration: number) => {
                const actx = getAudioContext();
                if(!actx) return;
                const o = actx.createOscillator();
                const g = actx.createGain();
                o.connect(g);
                g.connect(actx.destination);
                o.type = 'triangle';
                o.frequency.value = freq;
                g.gain.setValueAtTime(0, actx.currentTime + startTime);
                g.gain.linearRampToValueAtTime(0.3, actx.currentTime + startTime + 0.01);
                g.gain.linearRampToValueAtTime(0, actx.currentTime + startTime + duration);
                o.start(actx.currentTime + startTime);
                o.stop(actx.currentTime + startTime + duration);
            };
            playNote(523, 0, 0.15); // C
            playNote(659, 0.2, 0.15); // E
            playNote(783, 0.4, 0.15); // G
            playNote(1046, 0.6, 0.3); // C (high)
            return;
        }

        case 'click':
            oscillator.connect(gainNode);
            oscillator.type = 'triangle';
            oscillator.frequency.setValueAtTime(1200, now);
            gainNode.gain.setValueAtTime(0.2, now);
            gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.05);
            oscillator.start(now);
            oscillator.stop(now + 0.05);
            break;
    }
};