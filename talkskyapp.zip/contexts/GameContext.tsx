import React, { createContext, useReducer, useContext, Dispatch, useEffect, useCallback } from 'react';
import { AppState, GameState, Player, GameSettings } from '../types';
import { CATEGORIES, DEFAULT_TURN_DURATION, UI_TEXT } from '../constants';
import { db } from '../services/firebaseService';
import { doc, setDoc, getDoc, onSnapshot, Unsubscribe, deleteDoc } from 'firebase/firestore';

type GameAction =
  | { type: 'START_NEW_GAME', payload: { sessionId: string } }
  | { type: 'JOIN_GAME', payload: { gameId: string } }
  | { type: 'SET_GAME_STATE', payload: { state: AppState } }
  | { type: 'SYNC_STATE_FROM_DB', payload: { state: AppState } }
  | { type: 'LEAVE_GAME' }
  | { type: 'UPDATE_SETTINGS', payload: Partial<GameSettings> }
  | { type: 'ADD_PLAYER', payload: { player: Player, teamId: 'A' | 'B' } }
  | { type: 'REMOVE_PLAYER', payload: { playerId: string } }
  | { type: 'START_GAME_REQUEST' }
  | { type: 'START_GAME_SUCCESS', payload: { words: string[] } }
  | { type: 'START_GAME_FAILURE', payload: { error: string } }
  | { type: 'BEGIN_TURN' }
  | { type: 'TIMER_TICK' }
  | { type: 'CORRECT_GUESS' }
  | { type: 'SKIP_WORD' }
  | { type: 'END_TURN' }
  | { type: 'NEXT_TURN' }
  | { type: 'PLAY_AGAIN', payload: { sessionId: string } }
  | { type: 'CLEAR_ERROR' }
  | { type: 'SET_ERROR', payload: { error: string } };

const initialState: AppState = {
  gameId: null,
  hostSessionId: null,
  state: GameState.HOME,
  settings: {
    winningScore: 20,
    turnDuration: DEFAULT_TURN_DURATION,
    wordCategory: 'Random Words',
    language: 'en',
  },
  teams: {
    A: { id: 'A', name: 'Team A', players: [], score: 0, currentPlayerIndex: 0 },
    B: { id: 'B', name: 'Team B', players: [], score: 0, currentPlayerIndex: 0 },
  },
  words: [],
  currentTurn: {
    teamId: 'A',
    explainerId: null,
    turnData: {
      words: [],
      guessedWords: [],
      skippedWords: [],
    },
    timeRemaining: DEFAULT_TURN_DURATION,
  },
  isLoading: false,
  error: null,
};

const gameReducer = (state: AppState, action: GameAction): AppState => {
  // These actions are handled by middleware and directly update state
  if (action.type === 'SET_GAME_STATE' || action.type === 'SYNC_STATE_FROM_DB') {
    return action.payload.state;
  }
  if (action.type === 'SET_ERROR') {
      return { ...state, error: action.payload.error, isLoading: false };
  }

  // The rest of the actions describe intent, and the middleware will persist the result
  switch (action.type) {
    case 'LEAVE_GAME':
        return {
            ...initialState,
            settings: state.settings, // Preserve user's language setting
        }
    case 'CLEAR_ERROR':
        return { ...state, error: null };
    case 'TIMER_TICK':
        return {
            ...state,
            currentTurn: {
                ...state.currentTurn,
                timeRemaining: state.currentTurn.timeRemaining - 1,
            },
        };
    // The rest of the logic is now handled optimistically and persisted via middleware
    default:
        return state;
  }
};

const GameContext = createContext<{ gameState: AppState; dispatch: Dispatch<GameAction> } | undefined>(undefined);

// Helper function to update the game state in Firestore
const updateGameStateInFirestore = async (gameId: string, newState: AppState) => {
    if (!gameId) return;
    try {
        const gameRef = doc(db, 'games', gameId);
        await setDoc(gameRef, newState);
    } catch (error) {
        console.error("Error updating game state in Firestore:", error);
    }
};

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, baseDispatch] = useReducer(gameReducer, initialState);

  // Middleware to intercept actions and interact with Firestore
  const dispatch = useCallback(async (action: GameAction) => {
    const currentState = state; // Get state before any changes

    // Optimistic UI updates can be handled here if needed,
    // but for simplicity, we'll wait for DB confirmation.
    // For actions that need server-side logic (like creating a game), we handle them here.

    switch (action.type) {
        case 'START_NEW_GAME': {
            const gameId = Math.random().toString(36).substring(2, 8).toUpperCase();
            const newGameState: AppState = {
                ...initialState,
                gameId,
                hostSessionId: action.payload.sessionId,
                state: GameState.LOBBY,
                settings: {
                    ...initialState.settings,
                    language: currentState.settings.language, 
                    wordCategory: CATEGORIES[currentState.settings.language][0],
                },
                 teams: {
                    A: { ...initialState.teams.A, name: UI_TEXT[currentState.settings.language].teamA },
                    B: { ...initialState.teams.B, name: UI_TEXT[currentState.settings.language].teamB },
                }
            };
            await updateGameStateInFirestore(gameId, newGameState);
            baseDispatch({ type: 'SET_GAME_STATE', payload: { state: newGameState } });
            break;
        }

        case 'JOIN_GAME': {
            const gameId = action.payload.gameId;
            try {
                const gameRef = doc(db, 'games', gameId);
                const gameSnap = await getDoc(gameRef);
                if (gameSnap.exists()) {
                    const dbState = gameSnap.data() as AppState;
                    baseDispatch({ type: 'SET_GAME_STATE', payload: { state: dbState } });
                } else {
                    const errorText = UI_TEXT[currentState.settings.language].errorFindingGame;
                    baseDispatch({ type: 'SET_ERROR', payload: { error: errorText } });
                }
            } catch (error) {
                console.error("Error joining game:", error);
                const errorText = UI_TEXT[currentState.settings.language].errorFindingGame;
                baseDispatch({ type: 'SET_ERROR', payload: { error: errorText } });
            }
            break;
        }
        
        case 'LEAVE_GAME': {
            if (currentState.gameId && currentState.hostSessionId === sessionStorage.getItem('sessionId')) {
                // If host leaves, delete the game from DB
                await deleteDoc(doc(db, 'games', currentState.gameId));
            }
            baseDispatch(action);
            break;
        }

        // All other actions update the state and persist it
        default: {
            const tempState = gameReducer(currentState, action);
            if (tempState.gameId) {
                await updateGameStateInFirestore(tempState.gameId, tempState);
            } else {
                 baseDispatch(action);
            }
            break;
        }
    }
  }, [state]);

  // Listen for real-time updates from Firestore
  useEffect(() => {
    let unsubscribe: Unsubscribe | null = null;
    if (state.gameId) {
      const gameRef = doc(db, 'games', state.gameId);
      unsubscribe = onSnapshot(gameRef, (doc) => {
        if (doc.exists()) {
          const dbState = doc.data() as AppState;
          // Avoid overwriting local state if it's identical, prevents re-renders
          if (JSON.stringify(dbState) !== JSON.stringify(state)) {
             baseDispatch({ type: 'SYNC_STATE_FROM_DB', payload: { state: dbState } });
          }
        } else {
          // Game was deleted (e.g., host left)
          baseDispatch({ type: 'LEAVE_GAME' });
        }
      });
    }
    // Cleanup subscription on component unmount or when gameId changes
    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, [state.gameId, state]);


  return (
    <GameContext.Provider value={{ gameState: state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};
