import React, { useEffect, useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { GameState } from '../types';
import Button from '../components/Button';
import PlayerAvatar from '../components/PlayerAvatar';
import Card from '../components/Card';
import { UI_TEXT } from '../constants';
import { CheckIcon, XIcon } from '../components/icons';
import { playSound } from '../services/soundService';

const GameScreen: React.FC = () => {
    const { gameState, dispatch } = useGame();
    const { state, teams, currentTurn, settings } = gameState;
    const TEXT = UI_TEXT[settings.language];
    const [wordStatus, setWordStatus] = useState<'normal' | 'correct' | 'skipped'>('normal');
    const [isAnimating, setIsAnimating] = useState(false);
    const [sessionId, setSessionId] = useState('');

    useEffect(() => {
        setSessionId(sessionStorage.getItem('sessionId') || '');
    }, []);

    useEffect(() => {
        if (state !== GameState.PLAYING) return;
        if (currentTurn.timeRemaining <= 0) {
            playSound('turnEnd');
            dispatch({ type: 'END_TURN' });
            return;
        }

        const timer = setInterval(() => {
            dispatch({ type: 'TIMER_TICK' });
        }, 1000);

        return () => clearInterval(timer);
    }, [state, currentTurn.timeRemaining, dispatch]);
    
    const handleCorrect = () => {
        if (isAnimating) return;
        setIsAnimating(true);
        setWordStatus('correct');
        playSound('crowdCheer');
        setTimeout(() => {
            dispatch({type: 'CORRECT_GUESS'});
            setIsAnimating(false);
            setWordStatus('normal');
        }, 300);
    };

    const handleSkip = () => {
        if (isAnimating) return;
        setIsAnimating(true);
        setWordStatus('skipped');
        playSound('skip');
        setTimeout(() => {
            dispatch({type: 'SKIP_WORD'});
            setIsAnimating(false);
            setWordStatus('normal');
        }, 300);
    };


    const renderContent = () => {
        switch(state) {
            case GameState.TURN_START:
                return <TurnStart/>;
            case GameState.PLAYING:
                const isExplainer = sessionId === currentTurn.explainerId;
                return isExplainer ? <ExplainerView/> : <GuesserView />;
            case GameState.TURN_SUMMARY:
                return <TurnSummary/>;
            default:
                return null;
        }
    }
    
    const ScoreBar = () => (
        <div className="flex justify-between items-center w-full max-w-4xl mx-auto p-2 bg-white/50 backdrop-blur-sm border border-white/50 rounded-full mb-8 shadow-md">
            <div className="flex items-center">
                <div className="w-3 h-8 bg-team-a rounded-l-full rtl:rounded-r-full rtl:rounded-l-none"></div>
                <div className="bg-slate-100/50 p-2 ps-3 rounded-r-full rtl:rounded-l-full rtl:rounded-r-none">
                    <span className="font-bold text-xl text-dark">{teams.A.name}: {teams.A.score}</span>
                </div>
            </div>
             <div className="text-slate-500 font-bold text-lg">/ {settings.winningScore}</div>
            <div className="flex items-center">
                 <div className="bg-slate-100/50 p-2 pe-3 rounded-l-full rtl:rounded-r-full rtl:rounded-l-none">
                    <span className="font-bold text-xl text-dark">{teams.B.name}: {teams.B.score}</span>
                </div>
                <div className="w-3 h-8 bg-team-b rounded-r-full rtl:rounded-l-full rtl:rounded-r-none"></div>
            </div>
        </div>
    );


    const TurnStart: React.FC = () => {
        const team = teams[currentTurn.teamId];
        const explainer = team.players.find(p => p.id === currentTurn.explainerId);

        if (!explainer) return null;
        
        const isSelf = sessionId === explainer.id;

        return (
            <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center animate-fade-in">
                 <ScoreBar />
                <Card className="w-full max-w-md">
                    <h1 className="text-4xl font-bold mb-4 text-primary">
                      {isSelf ? TEXT.youAreTheExplainer : `${explainer.name} is Explaining`}
                    </h1>
                    <div className="flex flex-col items-center justify-center space-y-4 my-8">
                        <PlayerAvatar svg={explainer.avatarSvg} className={`w-24 h-24`} />
                        <p className="text-2xl font-semibold text-dark">{explainer.name}</p>
                    </div>
                    <p className="text-xl text-slate-600 mb-8">
                        {isSelf ? TEXT.explainerInstructions : `for ${team.name}`}
                    </p>
                    {isSelf &&
                        <Button
                            noSound
                            onClick={() => {
                                playSound('turnStart');
                                dispatch({type: 'BEGIN_TURN'});
                            }}
                            className="w-full text-lg py-4"
                        >
                            {TEXT.startTurn}
                        </Button>
                    }
                </Card>
            </div>
        );
    }
    
    const GuesserView: React.FC = () => {
        const timerColor = currentTurn.timeRemaining <= 10 ? 'text-red-500' : 'text-primary';
        const timerPulse = currentTurn.timeRemaining <= 5 ? 'animate-ping' : '';
        const team = teams[currentTurn.teamId];
        const explainer = team.players.find(p => p.id === currentTurn.explainerId);
        
        return (
             <div className="min-h-screen flex flex-col items-center justify-center p-4 md:p-8 text-center">
                <div className="w-full text-center mb-8">
                    <span className="text-slate-500 text-2xl">Score:</span> 
                    <span className="text-dark text-2xl font-bold ms-2">{teams[currentTurn.teamId].score}</span>
                </div>
                
                <div className={`text-center text-9xl font-extrabold relative my-auto ${timerColor}`}>
                    <span className={`absolute inset-0 opacity-25 ${timerPulse}`}>
                        {currentTurn.timeRemaining}
                    </span>
                    <span>{currentTurn.timeRemaining}</span>
                </div>
                
                {explainer && 
                    <div className="mb-8">
                        <p className="text-2xl text-dark">
                            <span className="font-bold">{explainer.name}</span> {TEXT.isExplainingFor} <span className="font-bold" style={{color: team.id === 'A' ? 'var(--color-team-a)' : 'var(--color-team-b)'}}>{team.name}</span>
                        </p>
                    </div>
                }
            </div>
        )
    }

    const ExplainerView: React.FC = () => {
        const currentWord = currentTurn.turnData.words[0] || '...';
        const timerColor = currentTurn.timeRemaining <= 10 ? 'text-red-500' : 'text-primary';
        const timerPulse = currentTurn.timeRemaining <= 5 ? 'animate-ping' : '';
        const wordPulseClass = currentTurn.timeRemaining <= 5 && wordStatus === 'normal' ? 'animate-text-pulse' : '';
        
        let wordAnimationClass = '';
        if (wordStatus === 'correct') wordAnimationClass = 'animate-fireworks';
        if (wordStatus === 'skipped') wordAnimationClass = 'animate-melt';

        const WordDisplay = () => {
            return (
                 <div className="relative">
                    <h2 className={`text-5xl md:text-8xl font-extrabold break-words text-dark transition-all duration-300 ${wordPulseClass} ${wordAnimationClass}`}>
                        {currentWord}
                    </h2>
                </div>
            )
        };
        
        return (
             <div className="min-h-screen flex flex-col items-center justify-between p-4 md:p-8">
                <div className="w-full flex justify-between items-center text-2xl font-bold">
                    <div className="w-1/3 text-left rtl:text-right">
                        <span className="text-slate-500">Score:</span> <span className="text-dark">{teams[currentTurn.teamId].score}</span>
                    </div>
                    <div className={`w-1/3 text-center text-5xl relative ${timerColor}`}>
                        <span className={`absolute inset-0 opacity-25 ${timerPulse}`}>
                            {currentTurn.timeRemaining}
                        </span>
                        <span>{currentTurn.timeRemaining}</span>
                    </div>
                    <div className="w-1/3 text-right rtl:text-left">
                        {/* Placeholder for layout */}
                    </div>
                </div>

                <div className="flex-grow flex items-center justify-center w-full">
                   <WordDisplay />
                </div>

                <div className="w-full grid grid-cols-2 gap-4 max-w-2xl mx-auto">
                    <Button
                        noSound
                        onClick={handleSkip}
                        variant="danger"
                        className="py-6 text-2xl"
                        disabled={isAnimating || currentTurn.turnData.words.length <= 1}
                    >
                        {TEXT.skip}
                    </Button>
                    <Button
                        noSound
                        onClick={handleCorrect}
                        variant="success"
                        className="py-6 text-2xl"
                        disabled={isAnimating}
                    >
                        {TEXT.correct}
                    </Button>
                </div>
            </div>
        );
    }
    
    const TurnSummary: React.FC = () => {
        const { guessedWords, skippedWords } = currentTurn.turnData;
        const points = guessedWords.length - skippedWords.length;
        
        const handleNextTurn = () => {
             dispatch({type: 'NEXT_TURN'});
        }

        return (
             <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center animate-fade-in">
                 <ScoreBar />
                <Card className="w-full max-w-2xl">
                    <h1 className="text-4xl font-bold mb-2 text-primary">{TEXT.turnOver}</h1>
                    <p className="text-xl mb-6 text-dark">You scored <span className="font-bold text-2xl text-emerald-600">{points > 0 ? `+${points}` : points}</span> points this round!</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left rtl:text-right">
                        <div>
                            <h3 className="font-bold text-lg text-emerald-600 mb-2 flex items-center">
                                <CheckIcon className="w-5 h-5 me-2"/> {TEXT.wordsGuessed} ({guessedWords.length})
                            </h3>
                            <ul className="bg-slate-100/50 p-3 rounded-lg max-h-40 overflow-y-auto">
                                {guessedWords.map(w => <li key={w} className="text-dark">{w}</li>)}
                                {guessedWords.length === 0 && <li className="text-slate-500 italic">None</li>}
                            </ul>
                        </div>
                         <div>
                            <h3 className="font-bold text-lg text-rose-600 mb-2 flex items-center">
                                <XIcon className="w-5 h-5 me-2"/> {TEXT.wordsSkipped} ({skippedWords.length})
                            </h3>
                            <ul className="bg-slate-100/50 p-3 rounded-lg max-h-40 overflow-y-auto">
                                {skippedWords.map(w => <li key={w} className="text-dark">{w}</li>)}
                                {skippedWords.length === 0 && <li className="text-slate-500 italic">None</li>}
                            </ul>
                        </div>
                    </div>

                    <Button onClick={handleNextTurn} className="w-full mt-8 text-lg py-4">{TEXT.nextTurn}</Button>
                </Card>
            </div>
        );
    }
    
    return renderContent();
};

export default GameScreen;
