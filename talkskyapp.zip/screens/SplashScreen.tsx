import React from 'react';
import { GameLogoIcon } from '../components/icons';

const SplashScreen: React.FC = () => {
    return (
        <div className="fixed inset-0 bg-gradient-to-br from-cyan-100 via-sky-200 to-blue-200 flex items-center justify-center z-50 pointer-events-none">
            <GameLogoIcon className="w-32 h-32 text-primary animate-scale-in-out" />
        </div>
    );
};

export default SplashScreen;