

import React, { useEffect } from 'react';
import { useGame } from '../contexts/GameContext';
import Card from '../components/Card';
import Button from '../components/Button';
import PlayerAvatar from '../components/PlayerAvatar';
import { UI_TEXT } from '../constants';
import { TrophyIcon } from '../components/icons';
import { playSound } from '../services/soundService';

const EndScreen: React.FC = () => {
  const { gameState, dispatch } = useGame();
  const { teams, settings } = gameState;
  const TEXT = UI_TEXT[settings.language];

  const winningTeam = teams.A.score >= settings.winningScore ? teams.A : teams.B;
  const losingTeam = winningTeam.id === 'A' ? teams.B : teams.A;
  const teamColor = winningTeam.id === 'A' ? 'text-team-a' : 'text-team-b';
  
  useEffect(() => {
    playSound('gameOver');
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center animate-fade-in">
        <TrophyIcon className={`w-24 h-24 mb-4 text-accent animate-bounce`} />
      <h1 className="text-6xl md:text-8xl font-extrabold text-dark mb-2">
        {winningTeam.name} {TEXT.teamWins}
      </h1>
      <p className="text-3xl font-bold mb-8">
        <span className={`${teamColor}`}>{winningTeam.score}</span>
        <span className="text-slate-400 mx-2">-</span>
        <span className="text-slate-600">{losingTeam.score}</span>
      </p>

      <Card className="w-full max-w-md animate-slide-in-up">
        <h2 className={`text-2xl font-bold mb-4 ${teamColor}`}>Winning Team</h2>
        <div className="space-y-3">
          {winningTeam.players.map(player => (
            <div key={player.id} className="flex items-center bg-slate-100 p-2 rounded-lg">
              <PlayerAvatar svg={player.avatarSvg} className={`w-10 h-10 ${teamColor}`} />
              <span className="ms-3 font-semibold text-dark">{player.name}</span>
            </div>
          ))}
        </div>
      </Card>

      <div className="mt-8 animate-slide-in-up" style={{ animationDelay: '200ms' }}>
        <Button onClick={() => dispatch({ type: 'PLAY_AGAIN', payload: { sessionId: sessionStorage.getItem('sessionId') || '' } })} className="py-4 px-10 text-xl">
          {TEXT.playAgain}
        </Button>
      </div>
    </div>
  );
};

export default EndScreen;
