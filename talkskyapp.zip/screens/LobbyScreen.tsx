import React, { useState, useCallback, useEffect } from 'react';
import { useGame } from '../contexts/GameContext';
import { generateWords } from '../services/geminiService';
import Button from '../components/Button';
import Card from '../components/Card';
import PlayerAvatar from '../components/PlayerAvatar';
import { UI_TEXT, CATEGORIES, LANGUAGES } from '../constants';
import { Team, Player } from '../types';
import AvatarPickerModal from '../components/AvatarPickerModal';
import { ClipboardIcon, ShareIcon } from '../components/icons';
import LoadingOverlay from '../components/LoadingOverlay';

// Moved PlayerJoinForm OUTSIDE of LobbyScreen component to prevent re-renders and input focus loss
const PlayerJoinForm: React.FC<{
    self: Player | undefined;
    playerName: string;
    setPlayerName: (name: string) => void;
    handleOpenAvatarPicker: (teamId: 'A' | 'B') => void;
    teams: { A: Team; B: Team };
    TEXT: typeof UI_TEXT['en'];
}> = ({ self, playerName, setPlayerName, handleOpenAvatarPicker, teams, TEXT }) => {
    if (self) return <p className="text-center text-lg text-slate-600 mb-8">{TEXT.waitingForHost}</p>;

    return (
        <Card className="mb-8 animate-slide-in-up" style={{ animationDelay: '200ms' }}>
            <h2 className="text-xl font-bold text-center text-dark mb-4">{TEXT.addYourselfToATeam}</h2>
            <div className="flex flex-col sm:flex-row gap-4">
                <input
                    type="text"
                    value={playerName}
                    onChange={e => setPlayerName(e.target.value)}
                    placeholder={TEXT.playerName}
                    className="flex-grow bg-white border border-slate-300 rounded-full shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-3 text-dark text-center sm:text-left rtl:sm:text-right"
                />
                <div className="flex gap-2">
                    <Button
                        onClick={() => handleOpenAvatarPicker('A')}
                        disabled={!playerName.trim() || teams.A.players.length >= 2}
                        className="!bg-team-a/80 hover:!bg-team-a text-white"
                    >
                        + {TEXT.teamA}
                    </Button>
                    <Button
                        onClick={() => handleOpenAvatarPicker('B')}
                        disabled={!playerName.trim() || teams.B.players.length >= 2}
                        className="!bg-team-b/80 hover:!bg-team-b text-white"
                    >
                        + {TEXT.teamB}
                    </Button>
                </div>
            </div>
        </Card>
    );
};


const LobbyScreen: React.FC<{ sessionId: string }> = ({ sessionId }) => {
    const { gameState, dispatch } = useGame();
    const { settings, teams, isLoading, error, gameId, hostSessionId } = gameState;
    const [playerName, setPlayerName] = useState('');
    const [isAvatarPickerOpen, setAvatarPickerOpen] = useState(false);
    const [selectedTeam, setSelectedTeam] = useState<'A' | 'B' | null>(null);
    const [copied, setCopied] = useState(false);

    const TEXT = UI_TEXT[settings.language];
    const isHost = sessionId === hostSessionId;

    const allPlayers = [...teams.A.players, ...teams.B.players];
    const self = allPlayers.find(p => p.id === sessionId);

    const handleOpenAvatarPicker = (teamId: 'A' | 'B') => {
        if (!playerName.trim() || self) return; // Can't join if already in a team
        const team = teams[teamId];
        if (team.players.length >= 2) return;
        setSelectedTeam(teamId);
        setAvatarPickerOpen(true);
    };

    const handleAvatarSelect = (avatarSvg: string) => {
        if (!selectedTeam || !playerName.trim()) return;

        dispatch({
            type: 'ADD_PLAYER',
            payload: {
                player: {
                    id: sessionId,
                    name: playerName.trim(),
                    avatarSvg,
                },
                teamId: selectedTeam
            }
        });

        setPlayerName('');
        setAvatarPickerOpen(false);
        setSelectedTeam(null);
    };

    const handleStartGame = useCallback(async () => {
        if (!isHost) return;
        dispatch({ type: 'START_GAME_REQUEST' });
        try {
            const words = await generateWords(settings.wordCategory, settings.language);
            dispatch({ type: 'START_GAME_SUCCESS', payload: { words } });
        } catch (err) {
            dispatch({ type: 'START_GAME_FAILURE', payload: { error: TEXT.errorGeneratingWords } });
        }
    }, [dispatch, settings.wordCategory, settings.language, isHost, TEXT.errorGeneratingWords]);

    const handleCopy = () => {
        if (!gameId) return;
        navigator.clipboard.writeText(gameId);
        setCopied(true);
    };

    const handleShare = () => {
        if (!gameId) return;
        const joinUrl = `${window.location.origin}?join=${gameId}`;
        const text = `Join my Talksky game! Code: ${gameId}\nOr click the link: ${joinUrl}`;
        const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
        window.open(whatsappUrl, '_blank');
    };

    useEffect(() => {
        if (copied) {
            const timer = setTimeout(() => setCopied(false), 2000);
            return () => clearTimeout(timer);
        }
    }, [copied]);

    const TeamColumn: React.FC<{ team: Team }> = ({ team }) => (
        <Card className="flex-1">
            <h2 className={`text-2xl font-bold mb-4 text-center ${team.id === 'A' ? 'text-team-a' : 'text-team-b'}`}>{team.name}</h2>
            <div className="space-y-3 min-h-[140px]">
                {team.players.map(p => (
                    <div key={p.id} className="flex items-center bg-slate-100 p-2 rounded-lg animate-pop-in">
                        <PlayerAvatar svg={p.avatarSvg} className={`w-10 h-10`} />
                        <span className="ms-3 font-semibold text-dark">{p.name}</span>
                    </div>
                ))}
            </div>
        </Card>
    );

    const canStartGame = isHost && teams.A.players.length > 0 && teams.B.players.length > 0 && settings.wordCategory;
    const inputStyles = "mt-1 block w-full bg-white border border-slate-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2 text-dark disabled:bg-slate-200/50 disabled:cursor-not-allowed";

    return (
        <div className="min-h-screen p-4 md:p-8 animate-fade-in">
            {isLoading && <LoadingOverlay text={TEXT.loadingWords} />}
            <div className="max-w-6xl mx-auto relative">
                <header className="flex justify-between items-center mb-6">
                    <h1 className="text-2xl font-bold text-dark">{TEXT.gameLobby}</h1>
                    <Button variant="secondary" onClick={() => dispatch({ type: 'LEAVE_GAME' })} className="py-2 px-4">
                        {TEXT.leaveGame}
                    </Button>
                </header>

                <div className="flex justify-center items-center mb-6">
                    <Card className="flex items-center gap-2 sm:gap-4 py-3">
                        <span className="text-slate-500 font-semibold hidden sm:inline">CODE:</span>
                        <span className="text-2xl sm:text-3xl font-extrabold text-dark tracking-widest">{gameId}</span>
                        <Button variant="secondary" onClick={handleCopy} className="py-2 px-3">
                            {copied ? TEXT.codeCopied : <ClipboardIcon className="w-5 h-5" />}
                        </Button>
                        <Button variant="secondary" onClick={handleShare} className="py-2 px-3">
                            <ShareIcon className="w-5 h-5" />
                        </Button>
                    </Card>
                </div>

                <Card className="mb-8 animate-slide-in-up">
                    <h2 className="text-2xl font-bold mb-4 text-dark rtl:text-right">Game Settings</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-slate-600 rtl:text-right">{TEXT.winningScore}</label>
                            <input type="number" value={settings.winningScore} disabled={!isHost}
                                onChange={e => dispatch({ type: 'UPDATE_SETTINGS', payload: { winningScore: parseInt(e.target.value) } })}
                                className={`${inputStyles} rtl:text-right`} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-600 rtl:text-right">{TEXT.turnDuration}</label>
                            <input type="number" value={settings.turnDuration} disabled={!isHost}
                                onChange={e => dispatch({ type: 'UPDATE_SETTINGS', payload: { turnDuration: parseInt(e.target.value) } })}
                                className={`${inputStyles} rtl:text-right`} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-600 rtl:text-right">{TEXT.language}</label>
                            <select value={settings.language} disabled={!isHost}
                                onChange={e => dispatch({ type: 'UPDATE_SETTINGS', payload: { language: e.target.value as typeof settings.language } })}
                                className={`${inputStyles} rtl:text-right`} >
                                {LANGUAGES.map(lang => <option key={lang.code} value={lang.code}>{lang.name}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-600 rtl:text-right">{TEXT.wordCategory}</label>
                            <select value={settings.wordCategory} disabled={!isHost}
                                onChange={e => dispatch({ type: 'UPDATE_SETTINGS', payload: { wordCategory: e.target.value } })}
                                className={`${inputStyles} rtl:text-right`} >
                                {CATEGORIES[settings.language].map(cat => <option key={cat} value={cat}>{cat}</option>)}
                            </select>
                        </div>
                    </div>
                </Card>

                <PlayerJoinForm
                    self={self}
                    playerName={playerName}
                    setPlayerName={setPlayerName}
                    handleOpenAvatarPicker={handleOpenAvatarPicker}
                    teams={teams}
                    TEXT={TEXT}
                />

                <div className="flex flex-col md:flex-row gap-8 mb-8 animate-slide-in-up" style={{ animationDelay: '100ms' }}>
                    <TeamColumn team={teams.A} />
                    <TeamColumn team={teams.B} />
                </div>

                <div className="text-center animate-slide-in-up" style={{ animationDelay: '300ms' }}>
                    {error && <p className="text-red-500 mb-4">{error}</p>}
                    {isHost && !canStartGame && <p className="text-yellow-600 mb-4">{TEXT.addPlayersToTeams}</p>}
                    {isHost &&
                        <Button
                            onClick={handleStartGame}
                            disabled={!canStartGame}
                            className="w-full md:w-auto py-4 px-10 text-xl"
                        >
                            {TEXT.startGame}
                        </Button>
                    }
                </div>
            </div>
            <AvatarPickerModal
                isOpen={isAvatarPickerOpen}
                onClose={() => setAvatarPickerOpen(false)}
                onSelect={handleAvatarSelect}
            />
        </div>
    );
};

export default LobbyScreen;