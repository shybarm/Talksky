export enum GameState {
  HOME = 'HOME',
  LOBBY = 'LOBBY',
  TURN_START = 'TURN_START',
  PLAYING = 'PLAYING',
  TURN_SUMMARY = 'TURN_SUMMARY',
  GAME_OVER = 'GAME_OVER',
}

export interface Player {
  id: string; 
  name: string;
  avatarSvg: string;
}

export interface Team {
  id: 'A' | 'B';
  name: string;
  players: Player[];
  score: number;
  currentPlayerIndex: number;
}

export interface GameSettings {
  winningScore: number;
  turnDuration: number;
  wordCategory: string;
  language: 'en' | 'es' | 'he' | 'ru';
}

export interface TurnData {
  words: string[];
  guessedWords: string[];
  skippedWords: string[];
}

export interface AppState {
  gameId: string | null;
  hostSessionId: string | null;
  state: GameState;
  settings: GameSettings;
  teams: { A: Team; B: Team };
  words: string[];
  currentTurn: {
    teamId: 'A' | 'B';
    explainerId: string | null;
    turnData: TurnData;
    timeRemaining: number;
  };
  isLoading: boolean;
  error: string | null;
}