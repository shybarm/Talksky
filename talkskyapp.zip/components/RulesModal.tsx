import React, { useEffect } from 'react';
import { useGame } from '../contexts/GameContext';
import { GAME_RULES, UI_TEXT } from '../constants';
import Card from './Card';
import Button from './Button';
import { XIcon } from './icons';

interface RulesModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
    const { gameState } = useGame();
    const { language } = gameState.settings;
    const TEXT = UI_TEXT[language];
    const RULES = GAME_RULES[language];

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };

        if (isOpen) {
            window.addEventListener('keydown', handleKeyDown);
        }

        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [isOpen, onClose]);

    if (!isOpen) {
        return null;
    }

    return (
        <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-modal-fade-in" 
            role="dialog"
            aria-modal="true"
            aria-labelledby="rules-title"
            onClick={onClose}
        >
            <Card 
                className="w-full max-w-2xl max-h-[90vh] flex flex-col animate-pop-in"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center mb-4">
                    <h2 id="rules-title" className="text-3xl font-bold text-primary">{RULES.title}</h2>
                    <button onClick={onClose} className="text-slate-400 hover:text-dark transition-colors" aria-label="Close">
                        <XIcon className="w-8 h-8"/>
                    </button>
                </div>
                <div className="overflow-y-auto space-y-4 pr-2 text-left rtl:text-right">
                    {RULES.rules.map((rule, index) => (
                        <div key={index}>
                            <h3 className="font-bold text-lg text-dark">{rule.title}</h3>
                            <p className="text-slate-600">{rule.description}</p>
                        </div>
                    ))}
                </div>
                <div className="mt-6 text-center">
                    <Button onClick={onClose} className="px-10 py-3">{TEXT.gotIt}</Button>
                </div>
            </Card>
        </div>
    );
};

export default RulesModal;