import React from 'react';
import { playSound } from '../services/soundService';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'success' | 'danger';
  noSound?: boolean;
}

const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', className = '', noSound = false, onClick, ...props }) => {
  const baseClasses = "font-bold py-3 px-6 rounded-full transition-all duration-200 ease-in-out focus:outline-none focus:ring-4 disabled:opacity-60 disabled:cursor-not-allowed transform hover:-translate-y-0.5 active:translate-y-0 disabled:hover:translate-y-0 shadow-md";

  const variantClasses = {
    primary: 'bg-accent hover:bg-yellow-500 text-dark shadow-yellow-500/30 focus:ring-yellow-500/50',
    secondary: 'bg-white/60 border border-slate-300 hover:bg-white text-dark focus:ring-cyan-500/50',
    success: 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/30 focus:ring-emerald-500/50',
    danger: 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/30 focus:ring-rose-500/50',
  };
  
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!noSound) {
      playSound('click');
    }
    if (onClick) {
      onClick(e);
    }
  };

  return (
    <button
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
      onClick={handleClick}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;