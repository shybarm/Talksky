import React from 'react';
import { GameLogoIcon } from './icons';

interface LoadingOverlayProps {
    text: string;
}

const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ text }) => {
    return (
        <div className="fixed inset-0 bg-light/80 backdrop-blur-sm flex flex-col items-center justify-center z-50 animate-fade-in">
            <GameLogoIcon className="w-24 h-24 text-primary animate-pulse" />
            <p className="mt-4 text-xl font-semibold text-dark">{text}</p>
        </div>
    );
};

export default LoadingOverlay;