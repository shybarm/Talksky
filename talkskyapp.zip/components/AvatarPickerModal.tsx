import React from 'react';
import Card from './Card';
import { XIcon } from './icons';
import { AVATARS } from './avatars';
import PlayerAvatar from './PlayerAvatar';
import { playSound } from '../services/soundService';

interface AvatarPickerModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSelect: (svg: string) => void;
}

const AvatarPickerModal: React.FC<AvatarPickerModalProps> = ({ isOpen, onClose, onSelect }) => {

    if (!isOpen) {
        return null;
    }
    
    const handleSelect = (svg: string) => {
        playSound('click');
        onSelect(svg);
    }

    return (
        <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-modal-fade-in" 
            role="dialog"
            aria-modal="true"
            aria-labelledby="avatar-picker-title"
            onClick={onClose}
        >
            <Card 
                className="w-full max-w-sm max-h-[90vh] flex flex-col animate-pop-in"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center mb-4">
                    <h2 id="avatar-picker-title" className="text-2xl font-bold text-dark">Select your avatar</h2>
                    <button onClick={onClose} className="text-slate-400 hover:text-dark transition-colors" aria-label="Close">
                        <XIcon className="w-8 h-8"/>
                    </button>
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-4 overflow-y-auto p-2">
                    {AVATARS.map((avatar, index) => (
                        <button
                            key={index}
                            onClick={() => handleSelect(avatar)}
                            className={`aspect-square rounded-full transition-transform hover:scale-105 p-1 focus:outline-none focus:ring-4 focus:ring-accent/50`}
                        >
                           <PlayerAvatar svg={avatar} className="w-full h-full" />
                        </button>
                    ))}
                </div>
            </Card>
        </div>
    );
};

export default AvatarPickerModal;