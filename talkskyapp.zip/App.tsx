
import React, { useState, useEffect, useCallback } from 'react';
import { useGame } from './contexts/GameContext';
import LobbyScreen from './screens/LobbyScreen';
import GameScreen from './screens/GameScreen';
import EndScreen from './screens/EndScreen';
import SplashScreen from './screens/SplashScreen';
import RulesModal from './components/RulesModal';
import { GameState } from './types';
import { GameLogoIcon } from './components/icons';
import Button from './components/Button';
import { UI_TEXT, LANGUAGES } from './constants';
import { playSound } from './services/soundService';

// Generate a unique session ID for the user
const getSessionId = (): string => {
    let id = sessionStorage.getItem('sessionId');
    if (!id) {
        id = crypto.randomUUID();
        sessionStorage.setItem('sessionId', id);
    }
    return id;
}

const App: React.FC = () => {
  const { gameState, dispatch } = useGame();
  const [showSplash, setShowSplash] = useState(!sessionStorage.getItem('splashShown'));
  const [sessionId] = useState(getSessionId());

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const joinGameId = urlParams.get('join');
    if (joinGameId) {
        dispatch({ type: 'JOIN_GAME', payload: { gameId: joinGameId.toUpperCase() } });
        // Clean up URL
        window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [dispatch]);

  useEffect(() => {
    if (showSplash) {
        playSound('intro');
        const timer = setTimeout(() => {
            setShowSplash(false);
            sessionStorage.setItem('splashShown', 'true');
        }, 2500);
        return () => clearTimeout(timer);
    }
  }, [showSplash]);
  
  useEffect(() => {
    document.documentElement.lang = gameState.settings.language;
    if (gameState.settings.language === 'he') {
        document.documentElement.dir = 'rtl';
    } else {
        document.documentElement.dir = 'ltr';
    }
  }, [gameState.settings.language]);

  const renderContent = () => {
    if (showSplash) {
        return <SplashScreen />;
    }
    
    switch (gameState.state) {
      case GameState.LOBBY:
        return <LobbyScreen sessionId={sessionId} />;
      case GameState.TURN_START:
      case GameState.PLAYING:
      case GameState.TURN_SUMMARY:
        return <GameScreen />;
      case GameState.GAME_OVER:
        return <EndScreen />;
      default:
        return <HomeScreen sessionId={sessionId}/>;
    }
  };
  
  const HomeScreen: React.FC<{sessionId: string}> = ({sessionId}) => {
    const [showRules, setShowRules] = useState(false);
    const [showJoin, setShowJoin] = useState(false);
    const [joinGameId, setJoinGameId] = useState('');
    const TEXT = UI_TEXT[gameState.settings.language];

    const handleStartNewGame = () => {
        dispatch({ type: 'START_NEW_GAME', payload: { sessionId } });
    };

    const handleJoinGame = useCallback((e: React.FormEvent) => {
        e.preventDefault();
        if (joinGameId.trim()) {
            dispatch({ type: 'JOIN_GAME', payload: { gameId: joinGameId.trim().toUpperCase() } });
        }
    }, [joinGameId, dispatch]);

    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center animate-fade-in">
            <GameLogoIcon className="w-24 h-24 text-primary mb-4" />
            <h1 className="text-6xl md:text-7xl font-extrabold text-dark mb-2">Talksky</h1>
            <p className="text-slate-500 text-lg mb-8 max-w-md">{TEXT.homeScreenSubtitle}</p>
            
            <div className="w-full max-w-sm mx-auto flex flex-col gap-4">
                { !showJoin ? (
                    <>
                        <Button onClick={handleStartNewGame} className="py-4 px-10 text-xl w-full">{TEXT.startGame}</Button>
                        <Button onClick={() => setShowJoin(true)} variant="secondary" className="py-4 px-10 text-xl w-full">{TEXT.joinGame}</Button>
                    </>
                ) : (
                    <form onSubmit={handleJoinGame} className="animate-fade-in">
                        <input
                            type="text"
                            value={joinGameId}
                            onChange={e => {
                                if (gameState.error) {
                                    dispatch({ type: 'CLEAR_ERROR' });
                                }
                                setJoinGameId(e.target.value);
                            }}
                            placeholder={TEXT.enterGameCode}
                            maxLength={6}
                            className="w-full text-center tracking-[0.3em] font-bold text-2xl bg-white border border-slate-300 rounded-full shadow-sm focus:ring-accent focus:border-accent p-3 text-dark uppercase mb-4"
                        />
                        <Button type="submit" className="py-4 px-10 text-xl w-full">{TEXT.joinGame}</Button>
                        {gameState.error && <p className="text-red-500 my-2 animate-fade-in">{gameState.error}</p>}
                         <button 
                            type="button"
                            onClick={() => {
                                setShowJoin(false)
                                if (gameState.error) {
                                    dispatch({ type: 'CLEAR_ERROR' });
                                }
                            }}
                            className="text-slate-500 mt-2 text-sm hover:underline">
                            {TEXT.cancel}
                        </button>
                    </form>
                )}
                
                <div className="flex items-center gap-4 mt-4">
                    <select
                        value={gameState.settings.language}
                        onChange={e => dispatch({ type: 'UPDATE_SETTINGS', payload: { language: e.target.value as typeof gameState.settings.language }})}
                        className="mt-1 block w-full bg-white border border-slate-300 rounded-full shadow-sm focus:ring-accent focus:border-accent text-lg p-3 text-dark text-center"
                    >
                        {LANGUAGES.map(lang => <option key={lang.code} value={lang.code}>{lang.name}</option>)}
                    </select>
                    <Button onClick={() => setShowRules(true)} variant="secondary" className="py-4 px-6 text-lg mt-1 whitespace-nowrap">{TEXT.howToPlay}</Button>
                </div>
            </div>

            <RulesModal isOpen={showRules} onClose={() => setShowRules(false)} />
        </div>
    );
  };

  return (
    <div className="min-h-screen font-sans">
      <main>{renderContent()}</main>
    </div>
  );
};

export default App;